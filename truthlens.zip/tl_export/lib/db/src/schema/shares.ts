import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const sharesTable = pgTable("shares", {
  id: text("id").primaryKey(),
  result: text("result").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Share = typeof sharesTable.$inferSelect;
