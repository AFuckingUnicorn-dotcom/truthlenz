import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";

export const paymentsTable = pgTable("payments", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  quantity: integer("quantity").notNull(),
  amount: text("amount").notNull(),
  status: text("status").notNull().default("pending"),
  pfPaymentId: text("pf_payment_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Payment = typeof paymentsTable.$inferSelect;
