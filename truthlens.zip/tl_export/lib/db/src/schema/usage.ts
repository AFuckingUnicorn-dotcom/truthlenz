import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usageTable = pgTable("usage", {
  id: text("id").primaryKey(),
  count: integer("count").notNull().default(0),
  credits: integer("credits").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertUsageSchema = createInsertSchema(usageTable);
export type InsertUsage = z.infer<typeof insertUsageSchema>;
export type Usage = typeof usageTable.$inferSelect;
