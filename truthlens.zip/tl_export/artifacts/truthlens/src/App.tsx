import { useEffect, useRef } from "react";
import { ClerkProvider, SignIn, SignUp, useClerk, useUser } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { dark } from "@clerk/themes";
import { Switch, Route, useLocation, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false, refetchOnWindowFocus: false },
  },
});

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY");
}

const clerkAppearance = {
  baseTheme: dark,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.png`,
  },
  variables: {
    colorPrimary: "#6c63ff",
    colorForeground: "#f0efe9",
    colorMutedForeground: "#8888a0",
    colorDanger: "#f87171",
    colorBackground: "#12121c",
    colorInput: "#0a0a12",
    colorInputForeground: "#f0efe9",
    colorNeutral: "#2a2a3a",
    fontFamily: "'Inter', -apple-system, sans-serif",
    borderRadius: "12px",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "rounded-[20px] w-[440px] max-w-full overflow-hidden",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: { color: "#f0efe9", fontWeight: "800" },
    headerSubtitle: { color: "#8888a0" },
    socialButtonsBlockButtonText: { color: "#f0efe9" },
    formFieldLabel: { color: "#8888a0" },
    footerActionLink: { color: "#7c6ff7" },
    footerActionText: { color: "#606080" },
    dividerText: { color: "#505068" },
    identityPreviewEditButton: { color: "#7c6ff7" },
    formFieldSuccessText: { color: "#34d399" },
    alertText: { color: "#f0efe9" },
    logoBox: "mb-2",
    logoImage: "rounded-[10px]",
    socialButtonsBlockButton: { background: "#1e1e2e", border: "1px solid #2a2a3a" },
    formButtonPrimary: { background: "#6c63ff" },
    formFieldInput: { background: "#0a0a12", border: "1px solid #1e1e2e", color: "#f0efe9" },
    footerAction: { borderTop: "1px solid #1e1e2e" },
    dividerLine: { background: "#1e1e2e" },
    alert: { background: "#1e0a0a", border: "1px solid #4a1818" },
    otpCodeFieldInput: { background: "#0a0a12", border: "1px solid #1e1e2e" },
    formFieldRow: {},
    main: {},
  },
};

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center px-4"
      style={{ background: "#0a0a0f" }}>
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        appearance={clerkAppearance}
      />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center px-4"
      style={{ background: "#0a0a0f" }}>
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
        appearance={clerkAppearance}
      />
    </div>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        qc.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);

  return null;
}

function UserBadge() {
  const { user, isLoaded } = useUser();
  const { signOut } = useClerk();

  if (!isLoaded || !user) return null;

  return (
    <div className="flex items-center gap-3">
      <span className="text-[13px]" style={{ color: "#8888a0" }}>
        {user.firstName ?? user.emailAddresses[0]?.emailAddress}
      </span>
      <button
        onClick={() => signOut({ redirectUrl: basePath || "/" })}
        className="text-[13px] px-3 py-1 rounded-full transition-colors"
        style={{ background: "#1e1e2e", border: "1px solid #2a2a3a",
          color: "#7c6ff7", cursor: "pointer", fontFamily: "inherit" }}>
        Sign out
      </button>
    </div>
  );
}

function AuthNav() {
  const { user, isLoaded } = useUser();
  const [, setLocation] = useLocation();

  if (!isLoaded) return null;

  if (user) return <UserBadge />;

  return (
    <div className="flex gap-2">
      <button
        onClick={() => setLocation("/sign-in")}
        className="text-[13px] px-4 py-[7px] rounded-full transition-colors"
        style={{ background: "none", border: "1px solid #2a2a3a",
          color: "#8888a0", cursor: "pointer", fontFamily: "inherit" }}>
        Sign in
      </button>
      <button
        onClick={() => setLocation("/sign-up")}
        className="text-[13px] px-4 py-[7px] rounded-full transition-colors"
        style={{ background: "#6c63ff", border: "none",
          color: "white", cursor: "pointer", fontFamily: "inherit" }}>
        Sign up
      </button>
    </div>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: { title: "Welcome back", subtitle: "Sign in to your TruthLens account" },
        },
        signUp: {
          start: { title: "Get started", subtitle: "Create your TruthLens account" },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <ClerkQueryClientCacheInvalidator />

          {/* Auth nav bar — shown on all pages */}
          <div className="fixed top-4 right-4 z-50">
            <AuthNav />
          </div>

          <Switch>
            <Route path="/" component={Home} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />
            <Route component={NotFound} />
          </Switch>

          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
