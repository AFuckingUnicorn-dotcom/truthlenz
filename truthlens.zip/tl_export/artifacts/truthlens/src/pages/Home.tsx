import React, { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";

const CONTEXTS = [
  { label: "Romantic interest", key: "romantic" },
  { label: "Workplace/boss",    key: "workplace" },
  { label: "Friend",            key: "friend" },
  { label: "Family",            key: "family" },
  { label: "Stranger",          key: "stranger" },
];

const MANIP_COLOR: Record<string, string> = {
  none: "#34d399", low: "#fbbf24", moderate: "#fb923c", high: "#f87171",
};

type AnalysisResult = {
  tone: string;
  intent: string;
  powerDynamic: string;
  manipulation: string;
  flirtProbability: number;
  flirtNote: string;
  signals: { name: string; pct: number }[];
  insights: { tag: string; color: string; text: string }[];
  verdict: string;
};

export default function Home() {
  const [message,      setMessage]      = useState("");
  const [context,      setContext]      = useState("");
  const [isPending,    setIsPending]    = useState(false);
  const [data,         setData]         = useState<AnalysisResult | null>(null);
  const [errorMsg,     setErrorMsg]     = useState("");
  const [isSharedView, setIsSharedView] = useState(false);
  const [shareLoading, setShareLoading] = useState(false);
  const [shareCopied,  setShareCopied]  = useState(false);
  const [shareError,   setShareError]   = useState("");

  const resultsRef = useRef<HTMLDivElement>(null);
  const BASE       = import.meta.env.BASE_URL.replace(/\/$/, "");

  // Load shared analysis from URL param on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const shareId = params.get("share");
    if (!shareId) return;

    setIsSharedView(true);
    setIsPending(true);
    fetch(`${BASE}/api/shares/${encodeURIComponent(shareId)}`)
      .then((r) => r.ok ? r.json() : Promise.reject())
      .then(({ result }) => {
        setData(result);
        setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
      })
      .catch(() => setErrorMsg("Could not load shared analysis."))
      .finally(() => setIsPending(false));
  }, [BASE]);

  const handleAnalyze = async () => {
    if (!message.trim()) return;
    setIsPending(true); setErrorMsg(""); setData(null); setIsSharedView(false);
    setShareCopied(false); setShareError("");
    try {
      const res = await fetch(`${BASE}/api/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: message.trim(), context: context || null }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        setErrorMsg((body as { error?: string }).error ?? "Something went wrong.");
        return;
      }
      const result: AnalysisResult = await res.json();
      setData(result);
      setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
    } catch { setErrorMsg("Something went wrong. Please try again."); }
    finally { setIsPending(false); }
  };

  const handleReset = () => {
    setMessage(""); setContext(""); setData(null); setErrorMsg("");
    setIsSharedView(false); setShareCopied(false); setShareError("");
    window.history.replaceState({}, "", window.location.pathname);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleShare = async () => {
    if (!data) return;
    setShareLoading(true); setShareError(""); setShareCopied(false);
    try {
      const res = await fetch(`${BASE}/api/shares`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result: data }),
      });
      if (!res.ok) throw new Error();
      const { id } = await res.json() as { id: string };
      const url = `${window.location.origin}${BASE || ""}/?share=${id}`;
      await navigator.clipboard.writeText(url);
      setShareCopied(true);
      window.history.replaceState({}, "", `?share=${id}`);
      setTimeout(() => setShareCopied(false), 3000);
    } catch {
      setShareError("Could not create share link.");
    } finally {
      setShareLoading(false);
    }
  };

  return (
    <div
      className="relative min-h-screen flex flex-col items-center px-6 pt-12 pb-24"
      style={{ background: "#0a0a0f", color: "#f0efe9", fontFamily: "'Inter', -apple-system, sans-serif" }}
    >
      {/* Amber glow */}
      <div className="fixed top-0 right-0 pointer-events-none z-0" style={{
        width: 600, height: 600,
        background: "radial-gradient(circle at 80% 20%, rgba(100,50,15,0.22) 0%, transparent 65%)",
      }} />

      <div className="w-full max-w-[780px] flex flex-col items-center relative z-10">

        {/* Logo pill */}
        <div className="inline-flex items-center gap-[10px] rounded-[14px] px-5 py-[10px] mb-6"
          style={{ background: "#14141e", border: "1px solid #2a2a3a" }}>
          <img src="/logo.png" alt="TruthLens logo" style={{ width: 32, height: 32, borderRadius: 8, objectFit: "cover" }} />
          <span className="text-[22px] font-extrabold" style={{ letterSpacing: "-0.3px" }}>
            Truth<span style={{ color: "#7c6ff7" }}>Lens</span>
          </span>
        </div>

        {/* Tagline */}
        <p className="text-[17px] text-center mb-8" style={{ color: "#8888a0" }}>
          Paste any message. Find out what it{" "}
          <em style={{ fontStyle: "italic", color: "#b0a8ff" }}>really</em> means.
        </p>

        {/* Shared view banner */}
        {isSharedView && data && (
          <div className="w-full rounded-[14px] px-5 py-3 mb-5 flex items-center gap-3"
            style={{ background: "#0e0e22", border: "1px solid #2a2860" }}>
            <span style={{ color: "#7c6ff7", fontSize: 16 }}>🔗</span>
            <span className="text-[14px]" style={{ color: "#8888a0" }}>
              You're viewing a shared analysis.
            </span>
            <button onClick={handleReset}
              className="ml-auto text-[13px] px-3 py-1 rounded-full"
              style={{ background: "#6c63ff", border: "none", color: "white",
                cursor: "pointer", fontFamily: "inherit" }}>
              Analyze your own
            </button>
          </div>
        )}

        {/* Input card — hidden in shared view */}
        {!isSharedView && (
          <div className="w-full rounded-[20px] p-8 mb-6"
            style={{ background: "#12121c", border: "1px solid #1e1e2e" }}>
            <FieldLabel>1. The Message</FieldLabel>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={"Paste the message here...\n\ne.g. \"Hmm interesting… we'll see.\""}
              rows={4}
              className="w-full rounded-[12px] p-4 text-[16px] leading-relaxed outline-none resize-none transition-colors mb-7"
              style={{ background: "#0a0a12", border: "1px solid #1e1e2e", color: "#f0efe9",
                minHeight: 130, fontFamily: "inherit" }}
              onFocus={(e) => (e.target.style.borderColor = "#6c63ff")}
              onBlur={(e)  => (e.target.style.borderColor = "#1e1e2e")}
            />

            <FieldLabel>2. The Context (Optional)</FieldLabel>
            <div className="flex flex-wrap gap-2 mb-7">
              {CONTEXTS.map((ctx) => (
                <button key={ctx.key}
                  onClick={() => setContext(context === ctx.key ? "" : ctx.key)}
                  className="text-[14px] px-4 py-2 rounded-full transition-all duration-150"
                  style={{
                    background: context === ctx.key ? "#6c63ff" : "#14141e",
                    border: `1px solid ${context === ctx.key ? "#6c63ff" : "#252535"}`,
                    color: context === ctx.key ? "white" : "#606080",
                    fontFamily: "inherit", cursor: "pointer",
                  }}>
                  {ctx.label}
                </button>
              ))}
            </div>

            <button
              onClick={handleAnalyze}
              disabled={!message.trim() || isPending}
              className="w-full py-4 rounded-[12px] text-[16px] font-semibold text-white flex items-center justify-center gap-[10px] transition-colors"
              style={{
                background: "#6c63ff", border: "none", fontFamily: "inherit",
                cursor: !message.trim() || isPending ? "not-allowed" : "pointer",
                opacity: !message.trim() || isPending ? 0.4 : 1,
              }}>
              {isPending
                ? <div className="w-[18px] h-[18px] rounded-full border-2 animate-spin"
                    style={{ borderColor: "rgba(255,255,255,0.3)", borderTopColor: "white" }} />
                : <><span style={{ fontSize: 18 }}>✦</span><span>Analyze Message</span></>}
            </button>

            {errorMsg && (
              <div className="mt-3 px-4 py-3 rounded-[10px] text-[14px]"
                style={{ background: "#1e0a0a", border: "1px solid #4a1818", color: "#f87171" }}>
                {errorMsg}
              </div>
            )}
          </div>
        )}

        {/* Loading spinner for shared view */}
        {isSharedView && isPending && (
          <div className="flex items-center gap-3 py-12" style={{ color: "#8888a0" }}>
            <div className="w-5 h-5 rounded-full border-2 animate-spin"
              style={{ borderColor: "rgba(108,99,255,0.3)", borderTopColor: "#6c63ff" }} />
            <span className="text-[15px]">Loading shared analysis…</span>
          </div>
        )}

        {/* Error for shared view */}
        {isSharedView && errorMsg && (
          <div className="w-full px-4 py-3 rounded-[10px] text-[14px] mb-6"
            style={{ background: "#1e0a0a", border: "1px solid #4a1818", color: "#f87171" }}>
            {errorMsg}
            <button onClick={handleReset} className="ml-3 underline" style={{ color: "#f87171", background: "none", border: "none", cursor: "pointer" }}>
              Go back
            </button>
          </div>
        )}

        {/* Results */}
        <AnimatePresence>
          {data && !isPending && (
            <motion.div ref={resultsRef} initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }} className="w-full mt-2">

              {/* Analysis Complete header */}
              <div className="flex items-center gap-3 mb-6 pb-4"
                style={{ borderBottom: "1px solid #1e1e2e" }}>
                <PulseIcon />
                <span className="text-[24px] font-extrabold text-white">Analysis Complete</span>
              </div>

              {/* 2×2 icon metric cards */}
              <div className="grid grid-cols-2 gap-3 mb-3">
                <IconCard badge="purple" icon={<IntentIcon />} label="True Intent"       value={data.intent} />
                <IconCard badge="orange" icon={<PowerIcon />}  label="Power Dynamic"    value={data.powerDynamic} />
                <IconCard badge="violet" icon={<ToneIcon />}   label="Overt Tone"       value={data.tone} />
                <IconCard badge="red"    icon={<WarnIcon />}   label="Manipulation Level"
                  value={data.manipulation} valueColor={MANIP_COLOR[data.manipulation]} />
              </div>

              {/* Flirt + Signals split row */}
              <div className="split-row mb-3">
                <div className="rounded-[16px] p-6 flex flex-col items-center text-center"
                  style={{ background: "#12121c", border: "1px solid #1e1e2e" }}>
                  <span className="text-[28px] mb-2" style={{ color: "#e08040" }}>♡</span>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.1em] mb-[10px] leading-snug"
                    style={{ color: "#505068" }}>
                    Attraction / Flirt<br />Probability
                  </p>
                  <motion.p className="font-extrabold leading-none mb-3"
                    initial={{ opacity: 0, scale: 0.7 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.2, type: "spring" }}
                    style={{ fontSize: 52, color: "#e08040" }}>
                    {data.flirtProbability}
                    <span style={{ fontSize: 28 }}>%</span>
                  </motion.p>
                  <div className="w-full h-[6px] rounded-full overflow-hidden mb-3"
                    style={{ background: "#0a0a14" }}>
                    <motion.div className="h-full rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${data.flirtProbability}%` }}
                      transition={{ duration: 1.2, delay: 0.2, ease: "easeOut" }}
                      style={{ background: "linear-gradient(90deg, #6c63ff, #e08040)" }} />
                  </div>
                  <p className="text-[13px] leading-relaxed" style={{ color: "#606080", fontStyle: "italic" }}>
                    {data.flirtNote}
                  </p>
                </div>

                <div className="rounded-[16px] p-6" style={{ background: "#12121c", border: "1px solid #1e1e2e" }}>
                  <div className="flex items-center gap-2 mb-5">
                    <PulseIcon />
                    <span className="text-[16px] font-bold text-white">Emotional Signals</span>
                  </div>
                  <div>
                    {data.signals.map((s) => (
                      <div key={s.name} className="mb-[14px] last:mb-0">
                        <div className="flex justify-between mb-[7px]">
                          <span className="text-[14px] font-medium" style={{ color: "#c0c0d8" }}>{s.name}</span>
                          <span className="text-[14px] font-medium" style={{ color: "#c0c0d8" }}>{s.pct}%</span>
                        </div>
                        <div className="h-[5px] rounded-full overflow-hidden" style={{ background: "#0a0a14" }}>
                          <motion.div className="h-full rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: `${s.pct}%` }}
                            transition={{ duration: 1, ease: "easeOut" }}
                            style={{ background: "#6c63ff" }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 3-col insights */}
              <div className="insights-row mb-3">
                {data.insights.map((ins, i) => (
                  <motion.div key={i}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * i }}
                    className="rounded-[16px] p-5"
                    style={{ background: "#0f0f1a", border: "1px solid #1a1a2e" }}>
                    <div className="flex items-center gap-[7px] mb-3">
                      <div className="w-[8px] h-[8px] rounded-full shrink-0" style={{ background: ins.color }} />
                      <span className="text-[11px] font-semibold uppercase tracking-[0.1em]"
                        style={{ color: ins.color }}>{ins.tag}</span>
                    </div>
                    <p className="text-[14px] leading-[1.7]" style={{ color: "#9090b0" }}>{ins.text}</p>
                  </motion.div>
                ))}
              </div>

              {/* Verdict */}
              <div className="w-full rounded-[20px] p-8 mb-6 relative overflow-hidden"
                style={{ background: "#0e0e22", border: "1px solid #2a2860" }}>
                <div className="absolute pointer-events-none"
                  style={{ right: -40, top: "50%", transform: "translateY(-50%)",
                    width: 220, height: 220, borderRadius: "50%",
                    border: "35px solid rgba(108,99,255,0.07)" }} />
                <div className="absolute pointer-events-none"
                  style={{ right: 70, top: "25%", width: 120, height: 120, borderRadius: "50%",
                    border: "25px solid rgba(108,99,255,0.04)" }} />
                <p className="text-[11px] font-bold uppercase tracking-[0.14em] mb-4 relative z-10"
                  style={{ color: "#6c63ff" }}>
                  The Bottom Line
                </p>
                <p className="font-extrabold leading-[1.55] text-white relative z-10"
                  style={{ fontSize: "clamp(18px, 2.2vw, 24px)" }}>
                  {data.verdict}
                </p>
              </div>

              {/* Action row */}
              <div className="flex items-center gap-4 flex-wrap">
                {!isSharedView && (
                  <button onClick={handleReset}
                    className="text-[14px] bg-transparent border-none cursor-pointer"
                    style={{ color: "#6c63ff", fontFamily: "inherit", padding: 0 }}>
                    ↺ Analyze another message
                  </button>
                )}

                <button
                  onClick={handleShare}
                  disabled={shareLoading}
                  className="flex items-center gap-2 text-[14px] px-4 py-2 rounded-full transition-all"
                  style={{
                    background: shareCopied ? "#0d1f13" : "#1e1e2e",
                    border: `1px solid ${shareCopied ? "#22543d" : "#2a2a3a"}`,
                    color: shareCopied ? "#6ee7b7" : "#8888a0",
                    fontFamily: "inherit", cursor: shareLoading ? "not-allowed" : "pointer",
                    opacity: shareLoading ? 0.6 : 1,
                  }}>
                  {shareLoading
                    ? <><div className="w-3 h-3 rounded-full border animate-spin"
                        style={{ borderColor: "rgba(136,136,160,0.3)", borderTopColor: "#8888a0" }} />
                      <span>Saving…</span></>
                    : shareCopied
                    ? <><span>✓</span><span>Link copied!</span></>
                    : <><ShareIcon /><span>Share analysis</span></>}
                </button>

                {shareError && (
                  <span className="text-[13px]" style={{ color: "#f87171" }}>{shareError}</span>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ── Sub-components ── */

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[11px] font-semibold uppercase tracking-[0.12em] mb-[10px]"
      style={{ color: "#44445a" }}>{children}</p>
  );
}

type BadgeColor = "purple" | "orange" | "violet" | "red";
const BADGE_BG: Record<BadgeColor, string> = {
  purple: "#1e1a3a", orange: "#2a1a0a", violet: "#1a1830", red: "#2a0f0f",
};

function IconCard({ badge, icon, label, value, valueColor }: {
  badge: BadgeColor; icon: React.ReactNode;
  label: string; value: string; valueColor?: string;
}) {
  return (
    <div className="rounded-[16px] p-5 flex items-start gap-[14px]"
      style={{ background: "#12121c", border: "1px solid #1e1e2e" }}>
      <div className="w-[42px] h-[42px] rounded-[10px] flex items-center justify-center shrink-0"
        style={{ background: BADGE_BG[badge] }}>
        {icon}
      </div>
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.1em] mb-[6px]"
          style={{ color: "#505068" }}>{label}</p>
        <p className="text-[15px] font-medium leading-snug"
          style={{ color: valueColor ?? "#e0dfff" }}>{value}</p>
      </div>
    </div>
  );
}

function ShareIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <circle cx="11" cy="2.5" r="1.5" stroke="#8888a0" strokeWidth="1.4" />
      <circle cx="11" cy="11.5" r="1.5" stroke="#8888a0" strokeWidth="1.4" />
      <circle cx="3" cy="7" r="1.5" stroke="#8888a0" strokeWidth="1.4" />
      <path d="M4.4 6.2L9.6 3.3M4.4 7.8L9.6 10.7" stroke="#8888a0" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

function PulseIcon() {
  return (
    <svg width="22" height="16" viewBox="0 0 22 16" fill="none">
      <path d="M1 8H5L7 2L9.5 14L12 5L14 10L16 8H21"
        stroke="#7c6ff7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function IntentIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <circle cx="11" cy="11" r="9" stroke="#7c6ff7" strokeWidth="1.6" />
      <circle cx="11" cy="11" r="5.5" stroke="#7c6ff7" strokeWidth="1.6" />
      <circle cx="11" cy="11" r="2" fill="#7c6ff7" />
    </svg>
  );
}

function PowerIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <path d="M13 2L5 13H11L9 20L17 9H11L13 2Z"
        fill="#e08040" stroke="#e08040" strokeWidth="0.5" strokeLinejoin="round" />
    </svg>
  );
}

function ToneIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <path d="M11 2V4M11 18V20M2 11H4M18 11H20M4.93 4.93L6.34 6.34M15.66 15.66L17.07 17.07M17.07 4.93L15.66 6.34M6.34 15.66L4.93 17.07"
        stroke="#9c8fff" strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="11" cy="11" r="3.5" fill="#9c8fff" />
    </svg>
  );
}

function WarnIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <path d="M11 3C11 3 3 18 3 18H19L11 3Z" stroke="#f87171" strokeWidth="1.8" strokeLinejoin="round" fill="none" />
      <line x1="11" y1="10" x2="11" y2="14" stroke="#f87171" strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="11" cy="16.5" r="0.9" fill="#f87171" />
    </svg>
  );
}
