import { Router, type IRouter } from "express";
import crypto from "node:crypto";
import { db, sharesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

router.post("/shares", async (req, res) => {
  const { result } = req.body as { result?: unknown };
  if (!result || typeof result !== "object") {
    res.status(400).json({ error: "result is required." });
    return;
  }

  const id = crypto.randomBytes(8).toString("hex");

  await db.insert(sharesTable).values({
    id,
    result: JSON.stringify(result),
  });

  res.json({ id });
});

router.get("/shares/:id", async (req, res) => {
  const { id } = req.params;
  const rows = await db.select().from(sharesTable).where(eq(sharesTable.id, id));
  if (!rows.length) {
    res.status(404).json({ error: "Share not found." });
    return;
  }

  try {
    res.json({ result: JSON.parse(rows[0].result) });
  } catch {
    res.status(500).json({ error: "Could not parse share data." });
  }
});

export default router;
