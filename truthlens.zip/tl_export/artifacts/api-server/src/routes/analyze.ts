import { Router, type IRouter } from "express";
import { anthropic } from "@workspace/integrations-anthropic-ai";

const router: IRouter = Router();

const ctxLabels: Record<string, string> = {
  romantic: "a romantic or potential romantic interest",
  "romantic interest": "a romantic or potential romantic interest",
  workplace: "a workplace context — boss, colleague, or client",
  "workplace/boss": "a workplace context — boss, colleague, or client",
  friend: "a friendship context",
  family: "a family member",
  stranger: "someone they just met or barely know",
};

router.post("/analyze", async (req, res) => {
  const { message, context } = req.body as {
    message?: string;
    context?: string | null;
    userId?: string;
  };

  if (!message || typeof message !== "string" || message.trim() === "") {
    res.status(400).json({ error: "Message is required." });
    return;
  }

  const ctxKey = context?.toLowerCase() ?? "";
  const ctxNote = ctxLabels[ctxKey]
    ? `Context: the sender is ${ctxLabels[ctxKey]}.`
    : "No context given — infer the most likely scenario.";

  const prompt = `You are TruthLens, a psychological message decoder. Be specific and confident — not vague.

Message: "${message.trim()}"
${ctxNote}

Return ONLY valid JSON, no markdown or explanation:
{
  "tone": "2-4 word emotional tone",
  "intent": "1 sentence on what sender wants",
  "powerDynamic": "1 sentence on who holds power",
  "manipulation": "none or low or moderate or high",
  "flirtProbability": <0-100 integer>,
  "flirtNote": "1 sentence on the flirt score",
  "signals": [
    {"name":"Confidence","pct":<0-100>},
    {"name":"Warmth","pct":<0-100>},
    {"name":"Defensiveness","pct":<0-100>},
    {"name":"Ambiguity","pct":<0-100>}
  ],
  "insights": [
    {"tag":"Emotional tone","color":"#818cf8","text":"1-2 sentences"},
    {"tag":"Power dynamic","color":"#34d399","text":"1-2 sentences"},
    {"tag":"Hidden subtext","color":"#fb923c","text":"1-2 sentences"}
  ],
  "verdict": "2-3 plain sentences — what this message really means and what the reader should know"
}`;

  try {
    const response = await anthropic.messages.create({
      model: "claude-haiku-4-5",
      max_tokens: 700,
      messages: [{ role: "user", content: prompt }],
    });

    const raw = response.content.find((b) => b.type === "text")?.text ?? "";
    const clean = raw.replace(/```json|```/g, "").trim();
    const result = JSON.parse(clean);

    res.json(result);
  } catch (err) {
    console.error("Analyze error:", err);
    res.status(500).json({ error: "Failed to analyze message. Please try again." });
  }
});

export default router;
