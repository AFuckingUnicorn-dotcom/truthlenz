import { Router, type IRouter } from "express";
import healthRouter from "./health";
import analyzeRouter from "./analyze";
import sharesRouter from "./shares";

const router: IRouter = Router();

router.use(healthRouter);
router.use(analyzeRouter);
router.use(sharesRouter);

export default router;
